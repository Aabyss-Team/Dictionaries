globalVariables = {}
